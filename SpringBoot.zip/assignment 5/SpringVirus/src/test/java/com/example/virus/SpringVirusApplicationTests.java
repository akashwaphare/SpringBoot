package com.example.virus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringVirusApplicationTests {

	@Test
	void contextLoads() {
	}

}
